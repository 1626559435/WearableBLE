# WearableBLE  低功耗蓝牙通信APP

通信格式为

printf("$%d$%d$%d$%d$%d",A,B,C,D,E);
其中，数据的个数可以更改，在APP工程里面的数据处理函数可以更改。
