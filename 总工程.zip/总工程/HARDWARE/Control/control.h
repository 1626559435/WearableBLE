#ifndef __CONTROL_H
#define __CONTROL_H
#include "stm32f10x.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"
#include "mpu6050.h"
#include "usmart.h"   
#include "inv_mpu.h"
#include "mpuiic.h"
#include "inv_mpu_dmp_motion_driver.h" 
#include "stm32f10x_gpioi2c.h" 
#include "stm32f10x_sensor.h"
#include "PulseSensor.h"
#include "timer.h"

void GetTemp(void);
void GetSteps(void);
void Get_BMP(void);
void TIM3_IRQHandler(void);   //TIM3�ж�



#endif
