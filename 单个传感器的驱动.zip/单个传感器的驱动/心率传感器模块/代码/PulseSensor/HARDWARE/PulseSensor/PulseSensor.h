#ifndef __PULSESENSOR_H
#define __PULSESENSOR_H

#include "stm32f10x.h"
#include "stm32f10x_adc.h"

void PulseSensorInit(void);
u16 Get_Adc(u8 ch);
u16 Get_Adc_Average(u8 ch,u8 times);

#endif

