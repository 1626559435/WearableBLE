 /**
   ******************************************************************************
   * @file	  stm32f10x_sensor.h
   * @author  MCD Application Team
   * @version V3.5.0
   * @date	  2020/03/21
   * @brief   Main program body
   ******************************************************************************
   */

#include "stm32f10x.h"

#ifndef __STM32F10x_SENSOR_H
#define __STM32F10x_SENSOR_H

typedef enum{
	SHT3x_DEVICE_ADDRES = 0x88,
	SHT3x_MODE_MSB = 0x22,
	SHT3x_MODE_LSB = 0x36,
	SHT3x_RESET_MSB = 0x30,
	SHT3x_RESET_LSB = 0xA2
}etSHT3xCommand;

#define	DS1307_Address 		0xD0		// DS1307设备地址
#define DS1307_RTCSTOP		0x80		// 停止RTC时钟
#define DS1307_RTCSTART		0x7F		// 激活RTC时钟
#define DS1307_12HOURS		0x20		// 12小时制
#define DS1307_24HOURS		0xDF		// 24小时制

/* DS1307 寄存器地址 */
#define DS1307_AddrSecs		0x00		// 秒
#define DS1307_AddrMin		0x01		// 分
#define DS1307_AddrHour		0x02		// 时
#define DS1307_AddrDay		0x03		// 周
#define DS1307_AddrData		0x04		// 日
#define DS1307_AddrMth		0x05		// 月
#define DS1307_AddrYear		0x06		// 年
#define DS1307_SQWModeOut	0x07		// 频率


void SHT3x_GetTempRH(float *SHT3x_GetTempRH);
void DS1307_WrClockRegInit(void);
uint8_t DS1307_BCDTODEC(uint8_t DS1307BCD);
void DS1307_ReadBuffer(uint8_t *GetTimeClock);



#endif

