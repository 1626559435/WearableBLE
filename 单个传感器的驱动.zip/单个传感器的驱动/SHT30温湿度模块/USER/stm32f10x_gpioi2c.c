/**
  ******************************************************************************
  * @file    stm32f10x_gpioi2c.c
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/03/21
  * @brief   Main program body
  ******************************************************************************
  */

#include "stm32f10x_gpioi2c.h"
#include "stm32f10x_system.h"

void I2C_GPIO_Configuration(void) { 
	GPIO_InitTypeDef  GPIO_InitStructure; 	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); 
	
    GPIO_InitStructure.GPIO_Pin = I2C_SDA_Pin | I2C_SCL_Pin;                       
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(I2C_Port, &GPIO_InitStructure);	
}

void I2C_GPIOx_Init(void) {
	IIC_SCL_SET();
	IIC_SDA_SET();
	DelayMs(1);
}

void I2C_Start(void) {
	IIC_SDA_OUT();
	IIC_SCL_SET();
	IIC_SDA_SET();
	DelayUs(1);
	IIC_SDA_CLR();
	DelayUs(1);
	IIC_SCL_CLR();
	DelayUs(1);
}

void I2C_Stop(void) {
	IIC_SDA_OUT();
	IIC_SCL_CLR();
	IIC_SDA_CLR();
	DelayUs(1);
	IIC_SCL_SET();
	DelayUs(1);
	IIC_SDA_SET();
	DelayUs(1);
}

bool I2C_Wait_For_Ack(void) {
	uint8_t chTimeOut = 0;
	
	IIC_SDA_IN();
	IIC_SDA_SET();
	DelayUs(1);
	IIC_SCL_SET();
	while ((!(IIC_SDA_READ())) && (chTimeOut ++)) {
		chTimeOut ++;
		if (chTimeOut > 200) {
			chTimeOut = 0;
			I2C_Stop();
			return false;
		}
	}
	IIC_SCL_CLR();
	DelayUs(1);
	return true;
}

void I2C_Ack(void) {
	IIC_SCL_CLR();
	IIC_SDA_OUT();
	IIC_SDA_CLR();
	DelayUs(1);
	IIC_SCL_SET();
	DelayUs(1);
	IIC_SCL_CLR();
}

void I2C_Nack(void) {
	IIC_SCL_CLR();
	IIC_SDA_OUT();
	IIC_SDA_SET();
	DelayUs(1);
	IIC_SCL_SET();
	DelayUs(1);
	IIC_SCL_CLR();
}

void I2C_Write_Byte(uint8_t chData) {
	uint8_t i = 0;
	
	IIC_SDA_OUT();
	for(i = 0; i < 8; i ++) {
		IIC_SCL_CLR();
		DelayUs(1);
		if(chData & 0x80) {
			IIC_SDA_SET();
		} else {
			IIC_SDA_CLR();
		}
		chData <<= 1;
		IIC_SCL_SET();
		DelayUs(1);
		IIC_SCL_CLR();
		DelayUs(1);
	}
}

void I2C_Write_OneByte(uint8_t chDevAddr, uint8_t chRegAddr, uint8_t chData) {
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_TX);
	I2C_Wait_For_Ack();
	I2C_Write_Byte(chRegAddr);
	I2C_Wait_For_Ack();
	I2C_Write_Byte(chData);
	I2C_Wait_For_Ack();
	I2C_Stop();
}

bool I2C_Write_Buffer(uint8_t chDevAddr, uint8_t *pchBuffer, uint8_t chNum) {
	uint8_t i = 0;

	if (0 == chNum || NULL == pchBuffer) {
		return false;
	}
	
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_TX);
	I2C_Wait_For_Ack();
	for (i = 0; i < chNum; i++) {
		I2C_Write_Byte(*(pchBuffer + i));
		I2C_Wait_For_Ack();
	}
	I2C_Stop();
	
	return true;
}

uint8_t I2C_Read_Byte(uint8_t chAck) {
	uint8_t i, chRecData = 0;

	IIC_SDA_IN();
	for (i = 0; i < 8; i ++) {
		IIC_SCL_CLR();
		DelayUs(1);
		IIC_SCL_SET();
		chRecData <<= 1;
		if(IIC_SDA_READ())
			chRecData |= 0x01;
		else
			chRecData &= ~0x01;
		DelayUs(1);
	}
	
	if (IIC_ACK == chAck) {
		I2C_Ack();
	} else {
		I2C_Nack();
	}
	
	return chRecData;
}

uint8_t I2C_Read_OneByte(uint8_t chDevAddr, uint8_t chRegAddr) {
	uint8_t chTemp = 0;
	
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_TX);
	I2C_Wait_For_Ack();
	I2C_Write_Byte(chRegAddr);
	I2C_Wait_For_Ack();
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_RX);
	I2C_Wait_For_Ack();
	chTemp = I2C_Read_Byte(IIC_NACK);
	I2C_Stop();
	
	return chTemp;
}


bool I2C_Read_Buffer(uint8_t chDevAddr, uint8_t *pchBuffer, uint8_t chNum) {
	uint8_t i;

	if (0 == chNum || NULL == pchBuffer) {
		return false;
	}
	
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_TX);
	I2C_Wait_For_Ack();
	I2C_Stop();
	I2C_Start();
	I2C_Write_Byte(chDevAddr | IIC_DIR_RX);
	I2C_Wait_For_Ack();

	for (i = 0; i < chNum; i ++) {
		if ((chNum - 1) == i) {
			*(pchBuffer + i) = I2C_Read_Byte(IIC_NACK);
		} else {
			*(pchBuffer + i) = I2C_Read_Byte(IIC_ACK);
		}
	}

	I2C_Stop();
	
	return true;
}


