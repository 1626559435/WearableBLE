/**
  ******************************************************************************
  * @file    stm32f10x_sensor.c
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/03/21
  * @brief   Main program body
  ******************************************************************************
  */  

#include "stdio.h"
#include "stm32f10x_sensor.h"
#include "stm32f10x_gpioi2c.h"
#include "stm32f10x_system.h"

/* SHT3x温湿度模块寄存器 */
uint8_t SHT3x_GetRegTempRH[6] = {0};
uint8_t SHT3x_RegAddr[2] = {SHT3x_MODE_MSB, SHT3x_MODE_LSB};

void SHT3x_GetTempRH(float *SHT3x_GetTempRH) {
	uint16_t temp = 0;
	uint16_t hum = 0;
	I2C_Write_Buffer(SHT3x_DEVICE_ADDRES, SHT3x_RegAddr, 2);
	DelayMs(50);
	I2C_Read_Buffer(SHT3x_DEVICE_ADDRES, SHT3x_GetRegTempRH, 6);
	temp = ((SHT3x_GetRegTempRH[0] << 8) | SHT3x_GetRegTempRH[1]);
	hum = ((SHT3x_GetRegTempRH[3] << 8) | SHT3x_GetRegTempRH[4]);
	*SHT3x_GetTempRH = ((175.0*(float)temp)/65535.0) - 46.8;
	SHT3x_GetTempRH++;
	*SHT3x_GetTempRH = (100.0*(float)hum)/65535.0;
}

