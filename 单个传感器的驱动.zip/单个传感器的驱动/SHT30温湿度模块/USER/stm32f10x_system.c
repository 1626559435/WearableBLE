/**
  ******************************************************************************
  * @file    stm32f10x_system.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/02/26
  * @brief   Main program body
  ******************************************************************************
  */  

#include "stdio.h"
#include "string.h"
#include "stm32f10x_system.h"
#include "stm32f10x_conf.h"


static __IO uint32_t TimingDelay;

uint8_t RxBuffer[USART_RxBuff_Size];
uint8_t RxCount = 0;

static uint8_t  s_chFacMicro = 0;
static uint16_t s_hwFacMill = 0;

void SysTick_Init(void)	   {
	RCC_ClocksTypeDef RCC_ClocksStructure;
	RCC_GetClocksFreq(&RCC_ClocksStructure); 
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);	 
	s_chFacMicro = (RCC_ClocksStructure.HCLK_Frequency) / 8000000;	  // SystemCoreClock 72Mhz
	s_hwFacMill = (uint16_t)s_chFacMicro * 1000;  
}

/**
 * @brief delay for n us.
 * @param wMicro = nus / (SystemCoreClock / 8000000)
 * @retval None 
 */
void DelayUs(uint32_t wMicro) {		
	uint32_t wTemp;
	
	SysTick->LOAD = wMicro * s_chFacMicro;   		 
	SysTick->VAL = 0x00;         
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;        
	do {
		wTemp = SysTick->CTRL;
	}
	while(wTemp & 0x01 && !(wTemp & (1 << 16)));   
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;       
	SysTick->VAL = 0X00;       
}

/**
 * @brief delay for n ms.
 * @param hwMill = (nms / (SystemCoreClock / 8000000)) * 1000
 * @retval None
 */
void DelayMs(uint16_t hwMill) {	 		  	  
	uint32_t wTemp;
	
	SysTick->LOAD = (uint32_t)hwMill * s_hwFacMill;
	SysTick->VAL = 0x00;           
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;         
	do {
		wTemp = SysTick->CTRL;
	}
	while(wTemp & 0x01 && !(wTemp & (1 << 16)));
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;       
	SysTick->VAL = 0X00;       
} 



/* USART1 串口收发函数 */
void STM32F10x_USART_Init(void) {
	USART_InitTypeDef USART_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
		 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);

	GPIO_InitStructure.GPIO_Pin = USART_GPIOx_Tx_Pin; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(USART_GPIOx_Port, &GPIO_InitStructure); 

    GPIO_InitStructure.GPIO_Pin = USART_GPIOx_Rx_Pin; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(USART_GPIOx_Port, &GPIO_InitStructure);  
	
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART_Port, &USART_InitStructure); 
	USART_ITConfig(USART_Port, USART_IT_TXE, DISABLE);		// 串口发送中断使能
	USART_ITConfig(USART_Port, USART_IT_RXNE, DISABLE);		// 串口接收中断使能
    USART_Cmd(USART_Port, ENABLE);     
	USART_ClearFlag(USART_Port, USART_FLAG_TC);

	/* 中断优先级 */
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3 ;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;			
	NVIC_Init(&NVIC_InitStructure);
}

/* 中断函数入口 */
void USART2_IRQHandler(void) {
	uint8_t RxBuFF_FLAG = 0;
	if(USART_GetFlagStatus(USART_Port, USART_FLAG_RXNE) != RESET) {
		RxBuffer[RxCount++] = USART_ReceiveData(USART_Port);
		if(RxBuffer[RxCount -1] == 0x0D) {
			RxBuFF_FLAG = 1;
			RxCount = 0;
			USART_ITConfig(USART_Port, USART_IT_RXNE, DISABLE);
		}
		USART_ClearFlag(USART_Port, USART_FLAG_RXNE);
	}
	if(USART_GetFlagStatus(USART_Port, USART_FLAG_TXE) != RESET) {
		if(RxBuFF_FLAG == 1) {
			printf("打印串口数据: %s\r\n", RxBuffer);
			memset(RxBuffer, 0, USART_RxBuff_Size);		// 清空缓冲区
		}
		USART_ClearFlag(USART_Port, USART_FLAG_TXE);
		USART_ITConfig(USART_Port, USART_IT_TXE, DISABLE);
	}
}

/* printf 函数重定向 */
int fputc(int ch, FILE *f) {
	USART_ClearFlag(USART_Port, USART_FLAG_TC);		
	USART_SendData(USART_Port, (uint8_t)ch);
	while(USART_GetFlagStatus(USART_Port, USART_FLAG_TC) == RESET);
	return ch;
}

void STM32F10x_GPIOx_Init(void){ 
	GPIO_InitTypeDef  GPIO_InitStructure; 	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);    
	
    GPIO_InitStructure.GPIO_Pin = LED_BLUE_Pin;                       
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED_BLUE_Port, &GPIO_InitStructure);	
}


