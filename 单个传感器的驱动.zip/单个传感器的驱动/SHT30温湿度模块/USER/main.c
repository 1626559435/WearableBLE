/**
  ******************************************************************************
  * @file    main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/02/26
  * @brief   Main program body
  ******************************************************************************
  */  

#include "stdio.h"
#include "stm32f10x.h"
#include "stm32f10x_system.h"
#include "stm32f10x_sensor.h"
#include "stm32f10x_gpioi2c.h"

float GetTempHum[2] = {0};	

int main(void) {
	/* 初始化函数调用部分 */
	SystemInit();
	SysTick_Init();
	I2C_GPIO_Configuration();		// SDA->PB9  SCL->PB8
	I2C_GPIOx_Init();			
	STM32F10x_USART_Init();			// TX->PA2	 RX->PA3,不同的平台记住修改
	
	/* 函数执行主体 */
	
	while(1) {
		SHT3x_GetTempRH(GetTempHum);
		printf("Temp:%0.2f  Hum: %0.2f\r\n", GetTempHum[0], GetTempHum[1]);
		DelayMs(100);
	}
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
