/**
  ******************************************************************************
  * @file    stm32f10x_system.h
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/02/26
  * @brief   Main program body
  ******************************************************************************
  */  

#include "stm32f10x.h"

#ifndef __STM32F10x_SYSTEM_H
#define __STM32F10x_SYSTEM_H

void SysTick_Init(void);
void DelayMs(uint16_t hwMill);
void DelayUs(uint32_t wMicro);
void DelayMs1(__IO uint32_t nTime);

void STM32F10x_USART_Init(void);
void STM32F10x_GPIOx_Init(void);

#endif

