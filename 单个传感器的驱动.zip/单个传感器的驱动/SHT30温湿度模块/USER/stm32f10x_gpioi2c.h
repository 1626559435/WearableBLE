/**
  ******************************************************************************
  * @file    stm32f10x_gpioi2c.h
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    2020/03/21
  * @brief   Main program body
  ******************************************************************************
  */

#include "stm32f10x.h"
#include "stdio.h"
#include "stm32f10x_system.h"
#include "stm32f10x_conf.h"

#ifndef __STM32F10x_GPIOI2C_H
#define __STM32F10x_GPIOI2C_H

typedef enum {
	false = 0,
	true = 1
} bool;


enum {
	IIC_DIR_TX = 0,
	IIC_DIR_RX,
};

enum {
	IIC_SDA_IN = 0,
	IIC_SDA_OUT
};

enum {
	IIC_ACK = 0,
	IIC_NACK
};



#define IIC_SDA_SET()			GPIO_WriteBit(I2C_Port, I2C_SDA_Pin, Bit_SET)
#define IIC_SDA_CLR()			GPIO_WriteBit(I2C_Port, I2C_SDA_Pin, Bit_RESET)
#define IIC_SCL_SET()			GPIO_WriteBit(I2C_Port, I2C_SCL_Pin, Bit_SET)
#define IIC_SCL_CLR()			GPIO_WriteBit(I2C_Port, I2C_SCL_Pin, Bit_RESET)

#define IIC_SDA_READ()    		GPIO_ReadInputDataBit(I2C_Port, I2C_SDA_Pin)

#define IIC_SDA_IN()     		do { \
									GPIO_InitTypeDef GPIO_InitStructure; \
									GPIO_InitStructure.GPIO_Pin = I2C_SDA_Pin; \
									GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; \
									GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; \
									GPIO_Init(I2C_Port, &GPIO_InitStructure); \
								}while(0)				

#define IIC_SDA_OUT() 			do { \
									GPIO_InitTypeDef GPIO_InitStructure; \
									GPIO_InitStructure.GPIO_Pin = I2C_SDA_Pin; \
									GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; \
									GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; \
									GPIO_Init(I2C_Port, &GPIO_InitStructure); \
								}while(0)   




void I2C_GPIO_Configuration(void);
void I2C_GPIOx_Init(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Ack(void);
void I2C_Nack(void);
bool I2C_Wait_For_Ack(void);
void I2C_Write_Byte(uint8_t chData); 
void I2C_Write_OneByte(uint8_t chDevAddr, uint8_t chRegAddr, uint8_t chData);
bool I2C_Write_Buffer(uint8_t chDevAddr,  uint8_t *pchBuffer, uint8_t chNum);
uint8_t I2C_Read_Byte(uint8_t chAck);
uint8_t I2C_Read_OneByte(uint8_t chDevAddr, uint8_t chRegAddr);
bool I2C_Read_Buffer(uint8_t chDevAddr, uint8_t *pchBuffer, uint8_t chNum);

#endif

